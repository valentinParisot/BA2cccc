package ch.epfl.tchu.game;

/**
 *
 * @author valentin Parisot (326658)
 */
public interface StationConnectivity {

    public abstract boolean connected(Station s1, Station s2);


}
